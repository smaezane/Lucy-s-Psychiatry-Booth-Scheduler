/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package until;

import dataModel.Appointment;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import static java.time.temporal.TemporalQueries.zoneId;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author smaez
 */
public class AppointmentDAO {

    public ObservableList<Appointment> getAllAppointments() {
        ObservableList<Appointment> appointmentList = FXCollections.observableArrayList();
        try {
            String sql = "SELECT appointment.type, customer.customerName, customer.customerId, appointment.appointmentId, appointment.start, appointment.end, appointment.description "
                    + "FROM customer, appointment "
                    + "WHERE appointment.customerId = customer.customerId AND appointment.userId = 1";
            PreparedStatement ps = DBConnection.conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int appointmentId = rs.getInt("appointmentId");
                int customerId = rs.getInt("customerId");
                String customerName = rs.getString("customerName");
                Timestamp start = rs.getTimestamp("start");
                Timestamp end = rs.getTimestamp("end");
//                String startString = rs.getString("start");
//                String endString = rs.getString("end");
                String description = rs.getString("description");
                String type = rs.getString("type");

                ZoneId newzid = ZoneId.systemDefault();
                ZonedDateTime newzdtStart = start.toLocalDateTime().atZone(ZoneId.of("UTC"));
                ZonedDateTime newZoneStart = newzdtStart.withZoneSameInstant(newzid);
                LocalDateTime newLocalStart = newZoneStart.toLocalDateTime();
                String startString1 = newLocalStart.toString();

                ZonedDateTime newzdtEnd = end.toLocalDateTime().atZone(ZoneId.of("UTC"));
                ZonedDateTime newZoneEnd = newzdtEnd.withZoneSameInstant(newzid);
                LocalDateTime newLocalEnd = newZoneEnd.toLocalDateTime();
                String endString1 = newLocalEnd.toString();

//                LocalTime currentTime = LocalTime.now();
//                long timeDifference = ChronoUnit.MINUTES.between(currentTime, newLocalStart);
//                System.out.println(timeDifference);

//                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
//
//                LocalDateTime startTime = LocalDateTime.parse(startString, formatter);
//                LocalDateTime endTime = LocalDateTime.parse(endString, formatter);
//
//                ZoneId newzid = ZoneId.systemDefault();
//
//                LocalDateTime startTest = start.toInstant().atZone(newzid).toLocalDateTime();
//                LocalDateTime endTest = end.toInstant().atZone(newzid).toLocalDateTime();
//                System.out.println(startTest);
//                System.out.println(endTest);
//
//                ZonedDateTime newzdtStart = startTest.atZone(ZoneId.of("UTC"));
//                ZonedDateTime newZoneStart = newzdtStart.withZoneSameInstant(newzid);
//                LocalDateTime newLocalStart = newZoneStart.toLocalDateTime();
//                String localStart = newLocalStart.toString();
//
//                ZonedDateTime newzdtEnd = endTest.atZone(ZoneId.of("UTC"));
//                ZonedDateTime newZoneEnd = newzdtEnd.withZoneSameInstant(newzid);
//                LocalDateTime newLocalEnd = newZoneEnd.toLocalDateTime();
//                String localEnd = newLocalEnd.toString();
                Appointment a = new Appointment(appointmentId, customerName, customerId, newLocalStart, newLocalEnd, description, type);
                appointmentList.add(a);

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return appointmentList;

    }

}
