package until;

import dataModel.Appointment;
import dataModel.Customer;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import until.DBConnection;
import static until.DBConnection.conn;

public class CustomerDAO {

    public List<Customer> parseCustomerList() {

        String tCustomerName;
        int tCustomerId;
        String tAddress;
        int tAddressId;
        String tCity;
        int tCityId;
        String tPhone;
        ArrayList<Customer> custList = new ArrayList();

        try (
                PreparedStatement statement = DBConnection.getConn().prepareStatement("SELECT customer.customerName, address.address, address.phone, customer.customerId, address.addressId, "
                        + "city.cityId, city.city FROM customer, address, city WHERE customer.addressId = address.addressId AND address.cityId = city.cityId");
                ResultSet rs = statement.executeQuery();) {

//        public Customer(String customer, int customerId, String address, int addressId, String city, int cityId, String phone)
            while (rs.next()) {
                tCustomerId = rs.getInt("customer.customerId");
                tCustomerName = rs.getString("customer.customerName");
                tAddress = rs.getString("address.address");
                tAddressId = rs.getInt("addressId.address");
                tCity = rs.getString("city.city");
                tCityId = rs.getInt("city.cityId");
                tPhone = rs.getString("address.phone");
                custList.add(new Customer(tCustomerName, tCustomerId, tAddress, tAddressId, tCity, tCityId, tPhone));
                System.out.println(custList);

            }

        } catch (SQLException sqe) {
            System.out.println("There may be a problem with your SQL");
        } catch (Exception e) {
            System.out.println("Something else went wrong.");
        }
        
        return custList;

    }

    public ObservableList<Customer> getAllCustomers() {
        ObservableList<Customer> customerList = FXCollections.observableArrayList();
        try {
            String sql = "SELECT customer.customerName, address.address, address.phone, customer.customerId, address.addressId, "
                    + "city.cityId, city.city FROM customer, address, city WHERE customer.addressId = address.addressId AND address.cityId = city.cityId";
            PreparedStatement ps = DBConnection.conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int customerId = rs.getInt("customerId");
                String customerName = rs.getString("customerName");
                int addressId = rs.getInt("addressId");
                String address = rs.getString("address");
                String phone = rs.getString("phone");
                int cityId = rs.getInt("cityId");
                String city = rs.getString("city");
                Customer c = new Customer(customerName, customerId, address, addressId, city, cityId, phone);
                customerList.add(c);

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return customerList;

    }

   

    public void insertCustomerDB(Customer customer) {

        String sqlCity = "INSERT INTO city(city, countryId, createDate, createdBy, lastUpdate, lastUpdateBy) "
                + "VALUES (?, 1, now(), 'test', now(), 'test')";
        String cityId = null;

        try {
            PreparedStatement psCity = conn.prepareStatement(sqlCity);
            psCity.setString(1, customer.getCity());
            psCity = conn.prepareStatement("SELECT LAST_INSERT_ID() FROM city");
            psCity.execute();
            ResultSet rsCity = psCity.executeQuery();
            rsCity.next();
            cityId = rsCity.getString(1);

        } catch (SQLException ex) {
        }

        String sqlAddress = "INSERT INTO Address(addressId, address, address2, cityId, postalCode, phone, createDate, createdBy, lastUpdate, lastUpdateBy) "
                + "VALUES (?, test, ?, test, ?, now(), 'test', now(), 'test')";
        String AddressId = null;

        try {
            PreparedStatement psAddress = conn.prepareStatement(sqlAddress);
            psAddress.setString(1, customer.getAddress());
            psAddress.setString(3, cityId);
            psAddress.setString(5, customer.getPhone());
            
            psAddress.execute();
            psAddress = conn.prepareStatement("SELECT LAST_INSERT_ID() FROM address");

            ResultSet rsAddress = psAddress.executeQuery();
            rsAddress.next();
            AddressId = rsAddress.getString(1);

        } catch (SQLException ex) {
        }
        
         String sqlCustomer = "INSERT INTO customer(customerName, addressId, active, createDate, createdBy, lastUpdate, lastUpdateBy) "
                + "VALUES (?, ?, 1, now(), 'test', now(), 'test')";
        String CustomerId = null;

        try {
            PreparedStatement psCustomer = conn.prepareStatement(sqlCustomer);
            psCustomer.setString(1, customer.getCustomer());
            psCustomer.setString(2, AddressId);
                        
            psCustomer.execute();
            psCustomer = conn.prepareStatement("SELECT LAST_INSERT_ID() FROM customer");

            ResultSet rsCustomer = psCustomer.executeQuery();
            rsCustomer.next();
            CustomerId = rsCustomer.getString(1);

        } catch (SQLException ex) {
        }

    }

}

//public class CustomerDAO extends DataAccessObject<Customer> {
//    private static final String INSERT = "INSERT INTO customer (first_name. last_name, "
//            + "email, phone, address, city, country) VALUES (?, ?, ?, ?, ?, ?, ?)";
//    
//    public static final String GET_ONE = "SELECT customer_id, first_name, last_name, "
//            + "email, phone, address, city, state, zipcode FROM customer WHERE customer_id=?";
//
//    public static final String UPDATE = "UPDATE customer SET first_name = ?, last_name = ?,"
//            + "email = ?, phone = ?, address = ?, city = ?, country = ? WHERE customer_id = ?";
//    public CustomerDAO(Connection connection) {
//        super(connection);
//    }
//
//    
//    }
//    @Override
//    public Customer update(Customer dto) {
//        Customer customer = null;
//        try(PreparedStatement statement = this.connection.prepareStatement(UPDATE);){
//            }catch(SQLException e){
//                e.printStackTrace();
//                throw new RuntimeException(e);
//            }
//
//   private static final String INSERT = "INSERT INTO customer (first_name. last_name, "
//            + "email, phone, address, city, country) VALUES (?, ?, ?, ?, ?, ?, ?)";
//    public Customer create(Customer dto){
//        try(PreparedStatement statement = this.connection.prepareStatement (INSERT);){
//            statement.setString(1, dto.getFirstName());
//            statement.setString(2, dto.getLastName());
//            statement.setString(3, dto.getEmail());
//            statement.setString(4, dto.getPhone());
//            statement.setString(5,dto.getAddress());
//            statement.setString(6, dto.getCity());
//            statement.setString(7, dto.getCountry());
//            statement.execute();
//            return null;
//        }
//        catch(SQLException e){
//            e.printStackTrace();
//            throw new RuntimeException(e);
//            
//        }
//    }
//    public void delete(long id) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }

