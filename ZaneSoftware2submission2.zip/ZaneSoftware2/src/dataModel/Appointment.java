/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataModel;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


public class Appointment {

    public int getAppointmentId() {
        return appointmentId;
    }

    public void setAppointmentId(int appointmentId) {
        this.appointmentId = appointmentId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }
    
    int appointmentId;
    String customer;
    int customerId;    
    LocalDateTime start;
    LocalDateTime end;
    String description;
    String type;
    
        public Appointment(int appointmentId, String customer,  int customerId, LocalDateTime start, LocalDateTime end, String description, String type) {
            this.type = type;
        this.appointmentId = appointmentId;
        this.customerId = customerId;
        this.customer = customer;  

	

        this.start = start;
        this.end = end;
        this.description = description;
    }
      
       public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    } 

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }


    public LocalDateTime getStart() {
        return start;
    }

    public void setStart(LocalDateTime start) {
        this.start = start;
    }

    public LocalDateTime getEnd() {
        return end;
    }

    public void setEnd(LocalDateTime end) {
        this.end = end;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    
    
}
