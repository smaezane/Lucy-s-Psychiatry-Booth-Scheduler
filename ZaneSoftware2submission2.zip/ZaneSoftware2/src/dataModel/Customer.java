/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataModel;



/**
 *
 * @author smaez
 */
public class Customer {
    
    
    String customer;
    int customerId;
    String address;
    int addressId;
    String city;
    int cityId;
    String phone;
    public String getCity;
   

    
        public Customer(String customer, int customerId, String address, int addressId, String city, int cityId, String phone) {
        this.customer = customer;
        this.customerId = customerId;
        this.address = address;  
        this.addressId = addressId;
        this.city = city;
        this.cityId = cityId;
        this.phone = phone;
    }
        
               public Customer(String customer,  String address, String city,  String phone) {
            }

 public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public int getAddressId() {
        return addressId;
    }

    public void setAddressId(int addressId) {
        this.addressId = addressId;
    }

    public int getCityId() {
        return cityId;
    }

    public void setCityId(int cityId) {
        this.cityId = cityId;
    }
    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }


    

}