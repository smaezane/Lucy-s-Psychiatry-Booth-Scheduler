/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zanesoftware2;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import static until.DBConnection.conn;

/**
 * FXML Controller class
 *
 * @author smaez
 */
public class LandingScreenController implements Initializable {
    
    @FXML
    private Button editCust;
    @FXML
    private Button editApp;
    @FXML
    private ImageView image;
    @FXML
    private Button buttonReports;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }
    
    private void changeSceneCalendar() {
        Parent main = null;
        try {
            main = FXMLLoader.load(getClass().getResource("CalendarScreen.fxml"));
            Scene scene = new Scene(main);
            
            Stage stage = ZaneSoftware2.getStage();
            
            stage.setScene(scene);
            
            stage.show();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    private void changeSceneViewCustomer() {
        Parent main = null;
        try {
            main = FXMLLoader.load(getClass().getResource("ViewCustomerScreen.fxml"));
            Scene scene = new Scene(main);
            
            Stage stage = ZaneSoftware2.getStage();
            
            stage.setScene(scene);
            
            stage.show();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    @FXML
    private void handleEditCust(ActionEvent event) {
        changeSceneViewCustomer();
    }
    
    @FXML
    private void handleEditApp(ActionEvent event) {
        changeSceneCalendar();
        
    }
    
    @FXML
    private void handleReports(ActionEvent event) {
        Parent main = null;
        try {
            main = FXMLLoader.load(getClass().getResource("Reports.fxml"));
            Scene scene = new Scene(main);

            Stage stage = ZaneSoftware2.getStage();

            stage.setScene(scene);

            stage.show();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
