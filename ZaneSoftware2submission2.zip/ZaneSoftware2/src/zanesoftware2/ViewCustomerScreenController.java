/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zanesoftware2;

import dataModel.Appointment;
import dataModel.Customer;
import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Objects;
import java.util.ResourceBundle;
import static javafx.beans.binding.Bindings.not;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import until.CustomerDAO;
import static until.DBConnection.conn;

public class ViewCustomerScreenController implements Initializable {

    @FXML
    private TableView<Customer> customer;
    @FXML
    private Button goBack;
    @FXML
    private Button deleteCustomer;
    @FXML
    private TableColumn<Customer, String> colName;
    @FXML
    private TableColumn<Customer, String> colAdd;
    @FXML
    private TableColumn<Customer, String> colCity;
    @FXML
    private TableColumn<Customer, String> colPhone;
    @FXML
    private TextField inputCustName;
    @FXML
    private TextField inputAddName;
    @FXML
    private ComboBox<String> comboCity;
    @FXML
    private TextField inputPhone;
    @FXML
    private Button custSave;
    @FXML
    private Label custChangingLabels;

    CustomerDAO db = new CustomerDAO();
    ObservableList<Customer> custList = db.getAllCustomers();
    @FXML
    private Button custUpdate;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        colName.setCellValueFactory(new PropertyValueFactory<>("customer"));
        colAdd.setCellValueFactory(new PropertyValueFactory<>("address"));
        colCity.setCellValueFactory(new PropertyValueFactory<>("city"));
        colPhone.setCellValueFactory(new PropertyValueFactory<>("phone"));

        customer.setItems(custList);
        initializeCountry();

        customer.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> showCustomerDetails(newValue));
    }

    private void initializeCountry() {

        ResultSet rs = accessDB("SELECT city FROM city");
        try {
            while (rs.next()) {
                comboCity.getItems().add(rs.getString(1));
            }
        } catch (SQLException ex) {
//            Logger.getLogger(ComboBoxExampleController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public ResultSet accessDB(String sql) {

        ResultSet rs = null;
        try {
            Statement stmt;
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rs;
    }

    private void showCustomerDetails(Customer selectedCustomer) {

        inputCustName.setText(selectedCustomer.getCustomer());
        inputAddName.setText(selectedCustomer.getAddress());
        comboCity.getSelectionModel().select(selectedCustomer.getCity());
        inputPhone.setText(selectedCustomer.getPhone());

    }

    private void changeSceneGoBack() {
        Parent main = null;
        try {
            main = FXMLLoader.load(getClass().getResource("LandingScreen.fxml"));
            Scene scene = new Scene(main);

            Stage stage = ZaneSoftware2.getStage();

            stage.setScene(scene);

            stage.show();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    @FXML
    private void handleGoBack(ActionEvent event) {
        changeSceneGoBack();
    }

    @FXML
    private void handleDeleteCustomer(ActionEvent event) throws SQLException {
        try {

            if (customer.getSelectionModel().getSelectedItem() != null) {
                String sqlDeleteCustApps = "delete from appointment where customerId = ?";
                String sqlDeleteCust = "DELETE customer from customer WHERE customerId = ?";

                int custId = customer.getSelectionModel().getSelectedItem().getCustomerId();

                PreparedStatement psDeleteCustApps = conn.prepareStatement(sqlDeleteCustApps);
                psDeleteCustApps.setInt(1, custId);
                psDeleteCustApps.execute();

                PreparedStatement psDeleteCust = conn.prepareStatement(sqlDeleteCust);
                psDeleteCust.setInt(1, custId);
                psDeleteCust.execute();

                customer.getItems().clear();

                ObservableList<Customer> custList = db.getAllCustomers();
                customer.setItems(custList);
                inputCustName.clear();
                inputAddName.clear();
                inputPhone.clear();

                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Confirmation");
                alert.setContentText("Customer Info has been deleted");
                alert.showAndWait();

            } else {
                Alert err = new Alert(Alert.AlertType.ERROR);
                err.setTitle("Error");
                err.setHeaderText("Error!");
                err.setContentText("Please select a customer to Delete.");
                err.showAndWait();
            }

        } catch (NullPointerException e) {
            System.out.print("Caught NullPointerException");
        }
    }

    @FXML
    private void handleCustSave(ActionEvent event) throws SQLException {
        try {
            if (inputCustName.getText() == null || inputAddName.getText() == null || comboCity.getValue() == null || inputPhone.getText() == null) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("Information is not completly filled in!");
                alert.setContentText("Please fill out all fields");
                alert.showAndWait();
            } else {
                String custName = inputCustName.getText();
                String addName = inputAddName.getText();
                String cityName = comboCity.getValue();
                String Phone = inputPhone.getText();

                String sqlCityId = "SELECT cityId from city WHERE city LIKE ?";
                int cityId = 0;

                try {

                    PreparedStatement psCityId = conn.prepareStatement(sqlCityId);
                    psCityId.setString(1, cityName);

                    ResultSet rsCity = psCityId.executeQuery();
                    rsCity.next();
                    cityId = rsCity.getInt(1);

                    String sqlAddressCheck = "SELECT address from address WHERE address LIKE ?";
                    PreparedStatement psAddressCheck = conn.prepareStatement(sqlAddressCheck);
                    psAddressCheck.setString(1, addName);
                    ResultSet rsAddressCheck = psAddressCheck.executeQuery();
                    
                    if (rsAddressCheck.next() == false) {
                        Alert alert = new Alert(AlertType.CONFIRMATION, "Address does not exist in the database. Would you like to add it now?", ButtonType.YES, ButtonType.NO, ButtonType.CANCEL);
                        alert.showAndWait();

                        if (alert.getResult() == ButtonType.YES) {
                            

                            String sqlPhoneCheck = "SELECT phone from address WHERE phone LIKE ?";
                            PreparedStatement psPhoneCheck = conn.prepareStatement(sqlPhoneCheck);
                            psPhoneCheck.setString(1, Phone);

                            ResultSet rsPhoneCheck = psPhoneCheck.executeQuery();

                            if (rsPhoneCheck.next() == false) {
                                Alert alert2 = new Alert(AlertType.CONFIRMATION, "Phone does not exist in the database. Would you like to add it now?", ButtonType.YES, ButtonType.NO, ButtonType.CANCEL);
                                alert2.showAndWait();

                                if (alert2.getResult() == ButtonType.YES) {
                                    
                                    String sqlAddress = "INSERT INTO address(address, address2, cityId, postalCode, phone, createDate, createdBy, lastUpdate, lastUpdateBy) "
                                    + "VALUES (?, 'test', ?, 'test', ?, now(), 'test', now(), 'test')";
                            int AddressId = 0;

                            PreparedStatement psAddress = conn.prepareStatement(sqlAddress);
                            psAddress.setString(1, addName);
                            psAddress.setInt(2, cityId);
                            psAddress.setString(3, Phone);
                            psAddress.execute();

                            PreparedStatement psAddressId = conn.prepareStatement("SELECT LAST_INSERT_ID() FROM address");

                            ResultSet rsAddressId = psAddressId.executeQuery();
                            rsAddressId.next();
                            AddressId = rsAddressId.getInt(1);

                                    String sqlCustomer = "INSERT INTO customer(customerName, addressId, active, createDate, createdBy, lastUpdate, lastUpdateBy)"
                                            + "VALUES (?, ?, 1, now(), 'test', now(), 'test')";
                                    int CustomerId = 0;

                                    PreparedStatement psCustomer = conn.prepareStatement(sqlCustomer);
                                    psCustomer.setString(1, custName);
                                    psCustomer.setInt(2, AddressId);
                                    psCustomer.execute();

                                    PreparedStatement psCustomerId = conn.prepareStatement("SELECT LAST_INSERT_ID() FROM customer");

                                    ResultSet rsCustomerId = psCustomerId.executeQuery();
                                    rsCustomerId.next();
                                    CustomerId = rsCustomerId.getInt(1);
                                    customer.getItems().clear();
                                    ObservableList<Customer> custList = db.getAllCustomers();
                                    customer.setItems(custList);

                                    Alert alert3 = new Alert(Alert.AlertType.CONFIRMATION);
                                    alert3.setTitle("Confirmation");
                                    alert3.setContentText("Customer Info has been saved");
                                    alert3.showAndWait();
                                } else {
                                    Alert alert1 = new Alert(Alert.AlertType.ERROR);
                                    alert1.setTitle("ERROR");
                                    alert1.setContentText("Customer Info has not been saved. Please enter a valid Phone number");
                                    alert1.showAndWait();

                                }

                            }

                        } else {
                            Alert alert1 = new Alert(Alert.AlertType.ERROR);
                            alert1.setTitle("ERROR");
                            alert1.setContentText("Customer Info has not been saved. Please enter a valid Address");
                            alert1.showAndWait();

                        }

                    }
                    
                    String sqlPhoneCheck = "SELECT phone from address WHERE phone LIKE ?";
                            PreparedStatement psPhoneCheck = conn.prepareStatement(sqlPhoneCheck);
                            psPhoneCheck.setString(1, Phone);

                            ResultSet rsPhoneCheck = psPhoneCheck.executeQuery();

                            if (rsPhoneCheck.next() == false) {
                                Alert alert2 = new Alert(AlertType.CONFIRMATION, "Phone does not exist in the database. Would you like to add it now?", ButtonType.YES, ButtonType.NO, ButtonType.CANCEL);
                                alert2.showAndWait();

                                if (alert2.getResult() == ButtonType.YES) {                                    String sqlAddress = "INSERT INTO address(address, address2, cityId, postalCode, phone, createDate, createdBy, lastUpdate, lastUpdateBy) "
                                    + "VALUES (?, 'test', ?, 'test', ?, now(), 'test', now(), 'test')";
                            int AddressId = 0;

                            PreparedStatement psAddress = conn.prepareStatement(sqlAddress);
                            psAddress.setString(1, addName);
                            psAddress.setInt(2, cityId);
                            psAddress.setString(3, Phone);
                            psAddress.execute();

                            PreparedStatement psAddressId = conn.prepareStatement("SELECT LAST_INSERT_ID() FROM address");

                            ResultSet rsAddressId = psAddressId.executeQuery();
                            rsAddressId.next();
                            AddressId = rsAddressId.getInt(1);

                                    String sqlCustomer = "INSERT INTO customer(customerName, addressId, active, createDate, createdBy, lastUpdate, lastUpdateBy)"
                                            + "VALUES (?, ?, 1, now(), 'test', now(), 'test')";
                                    int CustomerId = 0;

                                    PreparedStatement psCustomer = conn.prepareStatement(sqlCustomer);
                                    psCustomer.setString(1, custName);
                                    psCustomer.setInt(2, AddressId);
                                    psCustomer.execute();

                                    PreparedStatement psCustomerId = conn.prepareStatement("SELECT LAST_INSERT_ID() FROM customer");

                                    ResultSet rsCustomerId = psCustomerId.executeQuery();
                                    rsCustomerId.next();
                                    CustomerId = rsCustomerId.getInt(1);
                                    customer.getItems().clear();
                                    ObservableList<Customer> custList = db.getAllCustomers();
                                    customer.setItems(custList);

                                    Alert alert3 = new Alert(Alert.AlertType.CONFIRMATION);
                                    alert3.setTitle("Confirmation");
                                    alert3.setContentText("Customer Info has been saved");
                                    alert3.showAndWait();
                                }
                                 else{
                                                                    Alert alert1 = new Alert(Alert.AlertType.ERROR);
                                    alert1.setTitle("ERROR");
                                    alert1.setContentText("Customer Info has not been saved. Please enter a valid Phone number");
                                    alert1.showAndWait();
                            }

                            }
                                               
                    
         
                } catch (SQLException ex) {
                }

            }

        } catch (NullPointerException e) {
            System.out.print("Caught NullPointerException");
        }
    }

    @FXML
    private void handleCustUpdate(ActionEvent event) throws SQLException {
        String custName = inputCustName.getText();
        String addName = inputAddName.getText();
        String cityName = comboCity.getValue();
        String Phone = inputPhone.getText();

        Customer a = customer.getSelectionModel().getSelectedItem();

        if (a != null) {
            int custIdOld = a.getCustomerId();
            String custNameOld = a.getCustomer();
            int addIdOld = a.getAddressId();
            String addNameOld = a.getAddress();
            String cityNameOld = a.getCity();
            String phoneOld = a.getPhone();

            String sqlCityId = "SELECT cityId from city WHERE city LIKE ?";

            PreparedStatement psCityId = conn.prepareStatement(sqlCityId);
            psCityId.setString(1, cityName);

            ResultSet rsCity = psCityId.executeQuery();
            rsCity.next();
            int cityId = rsCity.getInt(1);

            if (!custNameOld.equalsIgnoreCase(custName)) {

                String sqlUpdateCust = "Update customer SET customerName = ? WHERE customerId = ?";
                PreparedStatement ps = conn.prepareStatement(sqlUpdateCust);
                ps.setString(1, custName);
                ps.setInt(2, custIdOld);
                ps.execute();
                customer.getItems().clear();
                ObservableList<Customer> custList = db.getAllCustomers();
                customer.setItems(custList);

            }

            if (!addNameOld.equalsIgnoreCase(addName)) {

                String sqlUpdateAddName = "Update address SET address = ? WHERE addressId = ?";
                PreparedStatement ps = conn.prepareStatement(sqlUpdateAddName);
                ps.setString(1, addName);
                ps.setInt(2, addIdOld);
                ps.execute();
                customer.getItems().clear();
                ObservableList<Customer> custList = db.getAllCustomers();
                customer.setItems(custList);

            }

            if (!cityNameOld.equals(cityName)) {

                String sqlUpdateCityName = "Update address SET cityId = ? WHERE addressId = ?";
                PreparedStatement ps = conn.prepareStatement(sqlUpdateCityName);
                ps.setInt(1, cityId);
                ps.setInt(2, addIdOld);
                ps.execute();
                customer.getItems().clear();
                ObservableList<Customer> custList = db.getAllCustomers();
                customer.setItems(custList);

            }

            if (!phoneOld.equalsIgnoreCase(Phone)) {

                String sqlUpdatePhone = "Update address SET phone = ? WHERE addressID = ?";
                PreparedStatement ps = conn.prepareStatement(sqlUpdatePhone);
                ps.setString(1, Phone);
                ps.setInt(2, addIdOld);
                ps.execute();
                customer.getItems().clear();
                ObservableList<Customer> custList = db.getAllCustomers();
                customer.setItems(custList);

            }
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation");
            alert.setContentText("Customer Info has been updated");
            alert.showAndWait();

        }
    }

}
