/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zanesoftware2;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import until.DBConnection;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author smaez
 */
public class ZaneSoftware2 extends Application {
    
    static Stage stage;
    
    @Override
    public void start(Stage primaryStage) throws Exception {
//        Parent root = FXMLLoader.load(getClass().getResource("LoginScreen.fxml"));
        Parent root = FXMLLoader.load(getClass().getResource("LoginScreen.fxml"));
        
        Scene scene = new Scene(root);
        this.stage = primaryStage;
        
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    static Stage getStage() {
        return stage;
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {

        DBConnection.startConnection();
        
        
        
        
        
        launch(args);
        DBConnection.closeConnection();
        
    }
    
}
