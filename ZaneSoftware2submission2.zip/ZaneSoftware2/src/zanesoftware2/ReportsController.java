/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zanesoftware2;

import dataModel.Appointment;
import dataModel.Customer;
import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import until.DBConnection;

/**
 * FXML Controller class
 *
 * @author smaez
 */
public class ReportsController implements Initializable {

    @FXML
    private Button Consultant;
    @FXML
    private Button Appointments;
    @FXML
    private Button Phone;
    @FXML
    private Button goBack;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void handleSchedConsultant(ActionEvent event) throws SQLException {
        
       
        try {
            String sql = "SELECT user.userName, customer.customerName, customer.customerId, appointment.appointmentId, appointment.start, appointment.end, appointment.description "
                    + "FROM user, customer, appointment "
                    + "WHERE appointment.customerId = customer.customerId AND user.userId = appointment.userId AND appointment.userId = 1";
            PreparedStatement ps = DBConnection.conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            
            rs.next();
                String userName1 = rs.getString("userName");
                String customerName1 = rs.getString("customerName");
                String startString1 = rs.getString("start");
                String endString1 = rs.getString("end");
                String description1 = rs.getString("description");
                System.out.println("\r\n" +"Consultant: " + userName1);
                System.out.println(customerName1 + "    " + startString1 + "    " + endString1 + "    " + description1);
          
           
            while (rs.next()) {
                
                String customerName = rs.getString("customerName");
                String startString = rs.getString("start");
                String endString = rs.getString("end");
                String description = rs.getString("description");
                System.out.println(customerName + "    " + startString + "    " + endString + "    " + description);
            }
                
                
                String sql2 = "SELECT user.userName, customer.customerName, customer.customerId, appointment.appointmentId, appointment.start, appointment.end, appointment.description "
                    + "FROM user, customer, appointment "
                    + "WHERE appointment.customerId = customer.customerId AND user.userId = appointment.userId AND appointment.userId = 2";
            PreparedStatement ps2 = DBConnection.conn.prepareStatement(sql2);
            ResultSet rs2 = ps2.executeQuery();
            
            rs2.next();
                userName1 = rs2.getString("userName");           
                customerName1 = rs2.getString("customerName");
                startString1 = rs2.getString("start");
                endString1 = rs2.getString("end");
                description1 = rs2.getString("description");
                System.out.println("\r\n" + "Consultant: " + userName1);
                System.out.println(customerName1 + "    " + startString1 + "    " + endString1 + "    " + description1);

           
            while (rs2.next()) {

                String customerName = rs2.getString("customerName");
                String startString = rs2.getString("start");
                String endString = rs2.getString("end");
                String description = rs2.getString("description");
                System.out.println(customerName + "    " + startString + "    " + endString + "    " + description);
                
            }
            String sql3 = "SELECT user.userName, customer.customerName, customer.customerId, appointment.appointmentId, appointment.start, appointment.end, appointment.description "
                    + "FROM user, customer, appointment "
                    + "WHERE appointment.customerId = customer.customerId AND user.userId = appointment.userId AND appointment.userId = 3";
            PreparedStatement ps3 = DBConnection.conn.prepareStatement(sql3);
            ResultSet rs3 = ps3.executeQuery();
            
            rs3.next();
                userName1 = rs3.getString("userName");           
                customerName1 = rs3.getString("customerName");
                startString1 = rs3.getString("start");
                endString1 = rs3.getString("end");
                description1 = rs3.getString("description");
                System.out.println("\r\n" + "Consultant: " + userName1);
                System.out.println(customerName1 + "    " + startString1 + "    " + endString1 + "    " + description1);

           
            while (rs3.next()) {

                String customerName = rs3.getString("customerName");
                String startString = rs3.getString("start");
                String endString = rs3.getString("end");
                String description = rs3.getString("description");
                System.out.println(customerName + "    " + startString + "    " + endString + "    " + description);
                
            }
            
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
 
    }

    @FXML
    private void handleAppType(ActionEvent event) throws SQLException {
        
        System.out.println("\r\n" + "Appointment Types by Month" +"\r\n" );
        
        String sql = "select count(type) from appointment where type = 'Phobia'";
        PreparedStatement ps = DBConnection.conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        rs.next();
        
        int count = rs.getInt("count(type)");
        System.out.println("Phobia = " + count);
        
        sql = "select count(type) from appointment where type = 'Cognitive'";
        ps = DBConnection.conn.prepareStatement(sql);
        rs = ps.executeQuery();
        rs.next();
        
        count = rs.getInt("count(type)");
        System.out.println("Cognitive = " + count);
        
        
        sql = "select count(type) from appointment where type = 'Behavior'";
        ps = DBConnection.conn.prepareStatement(sql);
        rs = ps.executeQuery();
        rs.next();
        
        count = rs.getInt("count(type)");
        System.out.println("Behavior = " + count);
        
        
        sql = "select count(type) from appointment where type = 'Trauma'";
        ps = DBConnection.conn.prepareStatement(sql);
        rs = ps.executeQuery();
        rs.next();
        
        count = rs.getInt("count(type)");
        System.out.println("Trauma = " + count);
    }

    @FXML
    private void handlePhoneNums(ActionEvent event) throws SQLException {
        String sql = "select phone from address";
        PreparedStatement ps = DBConnection.conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        
        System.out.println("\r\n" + "List of Phone Numbers"+ "\r\n" );
        
        while (rs.next()) {
                
                String Phone = rs.getString("phone");
                System.out.println(Phone);
            }
        System.out.println("PI = " + Math.PI);
                
        
    }

    @FXML
    private void handleBack(ActionEvent event) {
        
                Parent main = null;
        try {
            main = FXMLLoader.load(getClass().getResource("LandingScreen.fxml"));
            Scene scene = new Scene(main);

            Stage stage = ZaneSoftware2.getStage();

            stage.setScene(scene);

            stage.show();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
}
