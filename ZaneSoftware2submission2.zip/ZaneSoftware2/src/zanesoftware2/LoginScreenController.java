/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zanesoftware2;

import java.io.IOException;
import static java.lang.Math.log;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import static until.DBConnection.conn;

/**
 *
 * @author smaez
 */
public class LoginScreenController implements Initializable {

    @FXML
    private Label label;
    @FXML
    private Button LoginButton;
    @FXML
    private Label lblUsername;
    @FXML
    private Label lblPassword;

    @FXML
    private ImageView image;
    @FXML
    private TextField usernameInput;
    @FXML
    private TextField passwordInput;
    
    Logger log = Logger.getLogger("log.txt");

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
                try {
            FileHandler file = new FileHandler("log.txt", true);
            SimpleFormatter formatter = new SimpleFormatter();
            file.setFormatter(formatter);
            log.addHandler(file);
            

        } catch (IOException ex) {}

        

        if (Locale.getDefault().getLanguage().equals("de")) {
            rb = ResourceBundle.getBundle("zanesoftware2/German", Locale.getDefault());

            lblUsername.setText(rb.getString("Username"));
            lblPassword.setText(rb.getString("Password"));
            LoginButton.setText(rb.getString("Login"));
            image.setImage(new Image("zanesoftware2/germanLucy.jpg"));
        } else {
            image.setImage(new Image("zanesoftware2/englishLucy.jpg"));

        }
    }

    private void sceneChange(Connection conn) throws SQLException {
        Parent main = null;
        String pass = passwordInput.getText();
        String user = usernameInput.getText();
        String DBpass = null;
        String DBuser = null;
        Statement statement = null;
        String query = "Select userName, password from user where userName='" + user + "';";

        try {
            statement = conn.createStatement();
            ResultSet rs = statement.executeQuery(query);
            while (rs.next()) {
                DBpass = rs.getString("userName");
                DBuser = rs.getString("password");

            }

            if (pass.equals(DBpass) && user.equals(DBuser)) {
                

                    log.log(Level.INFO, "Login SUCCESS");
                
                    try {
                        String sqlAppointmentTimes = "Select customer.customerName, start from appointment, customer "
                                + "WHERE appointment.customerId = customer.customerId AND appointment.userId = 1";
                        PreparedStatement psSqlAppointmentTimes = conn.prepareStatement(sqlAppointmentTimes);

                        ResultSet rsSqlAppointmentTimes = psSqlAppointmentTimes.executeQuery();

                        while (rsSqlAppointmentTimes.next()) {

                            Timestamp startTime = rsSqlAppointmentTimes.getTimestamp("start");
                            String custName = rsSqlAppointmentTimes.getString("customerName");

                            ZoneId newzid = ZoneId.systemDefault();
                            ZonedDateTime newzdtStart = startTime.toLocalDateTime().atZone(ZoneId.of("UTC"));
                            ZonedDateTime newZoneStart = newzdtStart.withZoneSameInstant(newzid);
                            LocalDateTime newLocalStart = newZoneStart.toLocalDateTime();

                            LocalTime currentTime = LocalTime.now();
                            long timeDifference = ChronoUnit.MINUTES.between(currentTime, newLocalStart);
                            System.out.println(timeDifference);

                            long interval = timeDifference;
                            if (interval > 0 && interval <= 15) {

                                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                                alert.setTitle("Upcoming Appointment!");
                                alert.setContentText("You have an appointment with " + custName + " starting in " + interval + "  minutes");
                                alert.setGraphic(null);
                                alert.showAndWait();
                            }
                        }
                    } catch (SQLException e) {
                        
                    }
                    try {

                    main = FXMLLoader.load(getClass().getResource("LandingScreen.fxml"));
                    Scene scene = new Scene(main);

                    Stage stage = ZaneSoftware2.getStage();

                    stage.setScene(scene);

                    stage.show();
                } catch (IOException ex) {
                }
            } else if (!pass.equals(DBpass) || !user.equals(DBuser)) {
                if (Locale.getDefault().getLanguage().equals("de")) {
                    ResourceBundle rb = ResourceBundle.getBundle("zanesoftware2/German", Locale.getDefault());

                    Alert a = new Alert(Alert.AlertType.ERROR);
                    a.setContentText(rb.getString("Alert"));
                    a.setHeaderText(null);
                    a.showAndWait();

                } else {
                    Alert a = new Alert(Alert.AlertType.ERROR);
                    a.setContentText("Login Failed. Please try again.");
                    a.setHeaderText(null);
                    a.showAndWait();
                   
                    log.log(Level.SEVERE, "Login FAILURE");
                    
                }
            }
        } catch (SQLException e) {

        } finally {
            if (statement != null) {
                statement.close();
            }
        }
    }

    @FXML
    private void handleLoginButtonAction(ActionEvent event) throws SQLException {
        sceneChange(conn);

    }
}
