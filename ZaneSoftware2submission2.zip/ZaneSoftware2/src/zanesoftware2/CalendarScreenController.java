/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zanesoftware2;

import dataModel.Appointment;
import dataModel.Customer;
import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.DayOfWeek;
import java.time.LocalDate;
import static java.time.LocalDate.now;
import java.time.LocalDateTime;
import static java.time.LocalDateTime.now;
import static java.time.LocalTime.now;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import until.AppointmentDAO;
import until.CustomerDAO;
import static until.DBConnection.conn;

/**
 * FXML Controller class
 *
 * @author smaez
 */
public class CalendarScreenController implements Initializable {

    @FXML
    private TableView<Appointment> calendarTable;
    @FXML
    private RadioButton radioMonth;
    @FXML
    private RadioButton radioWeek;
    @FXML
    private Button goBackButton;
    @FXML
    private Button deleteApp;
    @FXML
    private TableColumn<Appointment, String> colCust;
    @FXML
    private TableColumn<Appointment, String> colStart;
    @FXML
    private TableColumn<Appointment, String> colEnd;
    @FXML
    private TableColumn<Appointment, String> colDescription;
    @FXML
    private ComboBox<String> dropStartHour;
    @FXML
    private ComboBox<String> dropStartMin;
    @FXML
    private DatePicker pickDate;
    @FXML
    private ComboBox<String> dropEndHour;
    @FXML
    private ComboBox<String> dropEndMin;
    @FXML
    private TextField inputCustName;
    @FXML
    private TextField inputDescription;

    ObservableList<String> startHour = FXCollections.observableArrayList();
    ObservableList<String> startMinute = FXCollections.observableArrayList();
    ObservableList<String> endHour = FXCollections.observableArrayList();
    ObservableList<String> endMinute = FXCollections.observableArrayList();
    AppointmentDAO dba = new AppointmentDAO();
    ObservableList<Appointment> appList = dba.getAllAppointments();
    @FXML
    private ToggleGroup toggleGroup;
    @FXML
    private ComboBox<String> cmboType;
    @FXML
    private Button appUpdate;
    @FXML
    private Button appSave1;

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        //Lamba expression to show selected appointment information
        calendarTable.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> showAppointmentDetails(newValue));

        colCust.setCellValueFactory(new PropertyValueFactory<>("customer"));
        colStart.setCellValueFactory(new PropertyValueFactory<>("start"));
        colEnd.setCellValueFactory(new PropertyValueFactory<>("end"));
        colDescription.setCellValueFactory(new PropertyValueFactory<>("description"));

        calendarTable.setItems(appList);
        initializeType();

        startHour.addAll("00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11",
                "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23");
        startMinute.addAll("00", "15", "30", "45");
        endHour.addAll("00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11",
                "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23");
        endMinute.addAll("00", "15", "30", "45");
        dropStartHour.setItems(startHour);
        dropStartMin.setItems(startMinute);
        dropEndHour.setItems(endHour);
        dropEndMin.setItems(endMinute);

    }

    private void initializeType() {

        ResultSet rs = accessDB("SELECT DISTINCT type FROM appointment");
        try {
            while (rs.next()) {
                cmboType.getItems().add(rs.getString(1));
            }
        } catch (SQLException ex) {

        }
    }

    private void showAppointmentDetails(Appointment selectedAppointment) {

        inputCustName.setText(selectedAppointment.getCustomer());
        inputDescription.setText(selectedAppointment.getDescription());
        pickDate.setValue(selectedAppointment.getStart().toLocalDate());
        int startHour = selectedAppointment.getStart().toLocalTime().getHour();
        int startMin = selectedAppointment.getStart().toLocalTime().getMinute();
        int endHour = selectedAppointment.getEnd().toLocalTime().getHour();
        int endMin = selectedAppointment.getEnd().toLocalTime().getMinute();
        dropStartHour.setValue((new Integer(startHour)).toString());
        dropStartMin.setValue((new Integer(startMin)).toString());
        dropEndHour.setValue((new Integer(endHour)).toString());
        dropEndMin.setValue((new Integer(endMin)).toString());
        cmboType.getSelectionModel().select(selectedAppointment.getType());

    }

    private void changeSceneCancel() {
        Parent main = null;
        try {
            main = FXMLLoader.load(getClass().getResource("LandingScreen.fxml"));
            Scene scene = new Scene(main);

            Stage stage = ZaneSoftware2.getStage();

            stage.setScene(scene);

            stage.show();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    @FXML
    private void handleMonth(ActionEvent event) {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime nowPlus30 = now.plusDays(30);
        //Lambda expression filters appointment list by next 30 days.
        FilteredList<Appointment> filteredData = new FilteredList<>(appList);
        filteredData.setPredicate(row -> {

            LocalDateTime rowDate = row.getStart();

            return rowDate.isAfter(now) && rowDate.isBefore(nowPlus30);
        });
        calendarTable.setItems(filteredData);

    }

    @FXML
    private void handleWeek(ActionEvent event) {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime nowPlus7 = now.plusDays(7);
        //Lambda expression filters appointment list by next 7 days.
        FilteredList<Appointment> filteredData = new FilteredList<>(appList);
        filteredData.setPredicate(row -> {

            LocalDateTime rowDate = row.getStart();

            return rowDate.isAfter(now) && rowDate.isBefore(nowPlus7);
        });
        calendarTable.setItems(filteredData);

    }

    @FXML
    private void handleGoBack(ActionEvent event) {
        changeSceneCancel();
    }

    @FXML
    private void handleDelete(ActionEvent event) throws SQLException {

        if (calendarTable.getSelectionModel().getSelectedItem() != null) {
            try {
                String sqlDeleteApp = " DELETE appointment from appointment WHERE appointmentId = ?";

                int appId = calendarTable.getSelectionModel().getSelectedItem().getAppointmentId();

                PreparedStatement psDeleteApp = conn.prepareStatement(sqlDeleteApp);
                psDeleteApp.setInt(1, appId);
                psDeleteApp.execute();

//            calendarTable.getItems().clear();
//            ObservableList<Appointment> appList = dba.getAllAppointments();
//            calendarTable.setItems(appList);
                inputCustName.clear();
                inputDescription.clear();

                dropStartHour.getSelectionModel().select(0);
                dropStartMin.getSelectionModel().select(0);
                dropEndHour.getSelectionModel().select(0);
                dropEndMin.getSelectionModel().select(0);
                cmboType.getSelectionModel().select(0);
                pickDate.setValue(null);
            } catch (NullPointerException e) {
                System.out.print("Caught NullPointerException");
            }

        } else {
            Alert err = new Alert(Alert.AlertType.ERROR);
            err.setTitle("Error");
            err.setHeaderText("Error!");
            err.setContentText("Please select an appointment to Delete.");
            err.showAndWait();

        }
    }

    public ResultSet accessDB(String sql) {

        ResultSet rs = null;
        try {
            Statement stmt;
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);

        } catch (SQLException ex) {
            ex.printStackTrace();
        } catch (NullPointerException e) {
        }
        return rs;
    }

    @FXML
    private void handleStartHour(ActionEvent event) {
    }

    @FXML
    private void handleStartMin(ActionEvent event) {
    }

    @FXML
    private void handlePickDate(ActionEvent event) {
    }

    @FXML
    private void handleEndHour(ActionEvent event) {
    }

    @FXML
    private void handleEndMin(ActionEvent event) {
    }

    @FXML
    private void handleCustName(ActionEvent event) {
    }

    @FXML
    private void handleDescription(ActionEvent event) {
    }

    @FXML
    private void handleAppSave(ActionEvent event) throws Exception {

        if (pickDate.getValue() == null || dropStartHour.getValue() == null || dropStartMin.getValue() == null
                || dropEndHour.getValue() == null || dropEndMin.getValue() == null || inputCustName.getText() == null
                || inputDescription.getText() == null || cmboType.getValue() == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Information is not completly filled in!");
            alert.setContentText("Please fill out all fields and completely select date");
            alert.setGraphic(null);
            alert.showAndWait();
        } else {
            LocalDate date = pickDate.getValue();
            String sHour = dropStartHour.getValue();
            String sMinute = dropStartMin.getValue();
            String eHour = dropEndHour.getValue();
            String eMinute = dropEndMin.getValue();
            String custName = inputCustName.getText();
            String description = inputDescription.getText();
            String type = cmboType.getValue();
            int match = 1;
            String alertStart = null;
            String alertEnd = null;

            LocalDateTime ldtStart = LocalDateTime.of(date.getYear(), date.getMonthValue(), date.getDayOfMonth(), Integer.parseInt(sHour), Integer.parseInt(sMinute));
            ZonedDateTime locZdtStart = ZonedDateTime.of(ldtStart, ZoneId.systemDefault());
            ZonedDateTime utcZdtStart = locZdtStart.withZoneSameInstant(ZoneOffset.UTC);
            ZoneId ZoneStart = utcZdtStart.getZone();
            

            LocalDateTime ldtEnd = LocalDateTime.of(date.getYear(), date.getMonthValue(), date.getDayOfMonth(), Integer.parseInt(eHour), Integer.parseInt(eMinute));
            ZonedDateTime locZdtEnd = ZonedDateTime.of(ldtEnd, ZoneId.systemDefault());
            ZonedDateTime utcZdtEnd = locZdtEnd.withZoneSameInstant(ZoneOffset.UTC);
            
            Timestamp sqlStart = Timestamp.valueOf(utcZdtStart.toLocalDateTime());          
            Timestamp sqlEnd = Timestamp.valueOf(utcZdtEnd.toLocalDateTime());

            DayOfWeek startDay = DayOfWeek.from(ldtStart);

            String sqlAppointmentTimes = "Select start, end from appointment";
            PreparedStatement psSqlAppointmentTimes = conn.prepareStatement(sqlAppointmentTimes);

            ResultSet rsSqlAppointmentTimes = psSqlAppointmentTimes.executeQuery();

            String sqlCustomerCheck = "SELECT customerId, customerName from customer WHERE customerName LIKE ?";
            String sqlAppointment = "INSERT INTO appointment(customerId, userId, title, description, location, contact, type, url, start, end, createDate, createdBy, lastUpdate, lastUpdateBy)"
                    + "VALUES (?, 1, 'test', ?, 'url', 'contact', ?, 'url', ?, ?, now(), 'me', now(), 'me')";
            int customerId = 0;

            PreparedStatement psCustomerCheck = conn.prepareStatement(sqlCustomerCheck);
            psCustomerCheck.setString(1, custName);

            ResultSet rsCustomerCheck = psCustomerCheck.executeQuery();
            while (rsSqlAppointmentTimes.next()) {

                Timestamp startTime = rsSqlAppointmentTimes.getTimestamp("start");

                ZoneId newzid = ZoneId.systemDefault();
                ZonedDateTime newzdtStart = startTime.toLocalDateTime().atZone(ZoneId.of("UTC"));
                ZonedDateTime newLocalStart = newzdtStart.withZoneSameInstant(newzid);

                Timestamp endTime = rsSqlAppointmentTimes.getTimestamp("end");

                ZonedDateTime newzdtEnd = endTime.toLocalDateTime().atZone(ZoneId.of("UTC"));
                ZonedDateTime newLocalEnd = newzdtEnd.withZoneSameInstant(newzid);

                if (sqlStart.equals(startTime) || sqlStart.after(startTime) && sqlStart.before(endTime)) {
                    alertStart = newLocalStart.toString();
                    alertEnd = newLocalEnd.toString();
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Time Conflict!");
                    alert.setContentText(alertStart + " and " + alertEnd + "There is already an appointment scheduled between the above times");
                    alert.setGraphic(null);
                    alert.showAndWait();

                    ++match;
                    break;

                }
            }

            String sqlCustomerCheck1 = "SELECT customerId, customerName from customer WHERE customerName LIKE ?";

            PreparedStatement psCustomerCheck1 = conn.prepareStatement(sqlCustomerCheck1);
            psCustomerCheck1.setString(1, custName);

            ResultSet rsCustomerCheck1 = psCustomerCheck1.executeQuery();
            
            if (match > 1){
            
            }

          else if (rsCustomerCheck1.next() == false) {
              
              
                Alert alert3 = new Alert(Alert.AlertType.ERROR);
                alert3.setTitle("Error");
                alert3.setContentText("Customer does not exist. Please add customer to customer table before trying to add an appointment");
                alert3.setGraphic(null);
                alert3.showAndWait();

            }  else if (sHour.equals("01") || sHour.equals("02") || sHour.equals("03") || sHour.equals("04") || sHour.equals("05") || sHour.equals("06") || sHour.equals("07") || sHour.equals("08")
                    || sHour.equals("17") || sHour.equals("18") || sHour.equals("19") || sHour.equals("20") || sHour.equals("21") || sHour.equals("22") || sHour.equals("23") || sHour.equals("24")
                    || eHour.equals("01") || eHour.equals("02") || eHour.equals("03") || eHour.equals("04") || eHour.equals("05") || eHour.equals("06") || eHour.equals("07") || eHour.equals("08")
                    || eHour.equals("17") || eHour.equals("18") || eHour.equals("19") || eHour.equals("20") || eHour.equals("21") || eHour.equals("22") || eHour.equals("23") || eHour.equals("24")
                    || startDay.toString().equals("SATURDAY") || startDay.toString().equals("SUNDAY")) {
                Alert alert2 = new Alert(Alert.AlertType.ERROR);
                alert2.setTitle("Error");
                alert2.setHeaderText("Invalid Appointment Time");
                alert2.setContentText("Please set the appointment during our office hours. We are open Monday-Friday 9:00-17:00");
                alert2.setGraphic(null);
                alert2.showAndWait();

            } else if (ldtStart.isBefore(LocalDateTime.now())) {
                Alert alert3 = new Alert(Alert.AlertType.ERROR);
                alert3.setTitle("Error");
                alert3.setContentText("You may not schedule an appointment in the past");
                alert3.setGraphic(null);
                alert3.showAndWait();

            } else if (ldtStart.isAfter(ldtEnd) || ldtStart.equals(ldtEnd)) {
                Alert alert3 = new Alert(Alert.AlertType.ERROR);
                alert3.setTitle("Error");
                alert3.setContentText("Start time must be at least 15 minutes before End time");
                alert3.setGraphic(null);
                alert3.showAndWait();
            } else if (rsCustomerCheck.next() == false) {
                Alert alert3 = new Alert(Alert.AlertType.ERROR);
                alert3.setTitle("Error");
                alert3.setContentText("Customer does not exist. Please create a new customer in customer table before trying to add an appointment");
                alert3.setGraphic(null);
                alert3.showAndWait();

            } else {

                customerId = rsCustomerCheck.getInt(1);
                String customerName = rsCustomerCheck.getString(2);

                PreparedStatement psAppointment = conn.prepareStatement(sqlAppointment);
                psAppointment.setInt(1, customerId);
                psAppointment.setString(2, description);
                psAppointment.setString(3, type);
                psAppointment.setTimestamp(4, sqlStart);
                psAppointment.setTimestamp(5, sqlEnd);
                psAppointment.execute();

                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Saved!");
                alert.setContentText("Your appointment has been saved");
                alert.setGraphic(null);
                alert.showAndWait();

                calendarTable.getItems().clear();
                ObservableList<Appointment> appList = dba.getAllAppointments();
                calendarTable.setItems(appList);

            }
        }
    }

    @FXML
    private void handleComboType(ActionEvent event
    ) {
    }

    @FXML
    private void handleAppUpdate(ActionEvent event) throws SQLException {

        Appointment a = calendarTable.getSelectionModel().getSelectedItem();

        if (a == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setContentText("Please select an appointment to update");
            alert.setGraphic(null);
            alert.showAndWait();
        } else {
            LocalDate date = pickDate.getValue();
            String sHour = dropStartHour.getValue();
            String sMinute = dropStartMin.getValue();
            String eHour = dropEndHour.getValue();
            String eMinute = dropEndMin.getValue();
            String custName = inputCustName.getText();
            String description = inputDescription.getText();
            String type = cmboType.getValue();
            int match = 1;
            String alertStart = null;
            String alertEnd = null;

            LocalDateTime ldtStart = LocalDateTime.of(date.getYear(), date.getMonthValue(), date.getDayOfMonth(), Integer.parseInt(sHour), Integer.parseInt(sMinute));
            ZonedDateTime locZdtStart = ZonedDateTime.of(ldtStart, ZoneId.systemDefault());
            ZonedDateTime utcZdtStart = locZdtStart.withZoneSameInstant(ZoneOffset.UTC);

            LocalDateTime ldtEnd = LocalDateTime.of(date.getYear(), date.getMonthValue(), date.getDayOfMonth(), Integer.parseInt(eHour), Integer.parseInt(eMinute));
            ZonedDateTime locZdtEnd = ZonedDateTime.of(ldtEnd, ZoneId.systemDefault());
            ZonedDateTime utcZdtEnd = locZdtEnd.withZoneSameInstant(ZoneOffset.UTC);

            Timestamp sqlStart = Timestamp.from(utcZdtStart.toInstant());
            Timestamp sqlEnd = Timestamp.from(utcZdtEnd.toInstant());

            DayOfWeek startDay = DayOfWeek.from(ldtStart);

            String custNameOld = a.getCustomer();
            int appIdOld = a.getAppointmentId();
            String typeOld = a.getType();
            String descriptionOld = a.getDescription();
            LocalDateTime startOld = a.getStart();
            LocalDateTime endOld = a.getEnd();

            String sqlAppointmentTimes = "Select start, end from appointment";
            PreparedStatement psSqlAppointmentTimes = conn.prepareStatement(sqlAppointmentTimes);

            ResultSet rsSqlAppointmentTimes = psSqlAppointmentTimes.executeQuery();

            String sqlCustId = "SELECT customerId from customer WHERE customerName LIKE ?";

            PreparedStatement psCustId = conn.prepareStatement(sqlCustId);
            psCustId.setString(1, custName);

            ResultSet rsCust = psCustId.executeQuery();
            rsCust.next();
            int custId = rsCust.getInt(1);

            if (!custNameOld.equalsIgnoreCase(custName)) {

                String sqlCustomerCheck1 = "SELECT customerId, customerName from customer WHERE customerName LIKE ?";

                PreparedStatement psCustomerCheck1 = conn.prepareStatement(sqlCustomerCheck1);
                psCustomerCheck1.setString(1, custName);

                ResultSet rsCustomerCheck1 = psCustomerCheck1.executeQuery();

                if (rsCustomerCheck1.next() == false) {
                    Alert alert3 = new Alert(Alert.AlertType.ERROR);
                    alert3.setTitle("Error");
                    alert3.setContentText("Customer does not exist. Please add customer to customer table before trying to add an appointment");
                    alert3.setGraphic(null);
                    alert3.showAndWait();

                } else {

                    String sqlUpdateCust = "Update appointment SET customerId = ? WHERE appointmentId = ?";
                    PreparedStatement ps = conn.prepareStatement(sqlUpdateCust);
                    ps.setInt(1, custId);
                    ps.setInt(2, appIdOld);
                    ps.execute();
                    calendarTable.getItems().clear();
                    ObservableList<Appointment> appList = dba.getAllAppointments();
                    calendarTable.setItems(appList);
                }

            } else if (!descriptionOld.equalsIgnoreCase(description)) {

                String sqlUpdateDescription = "Update appointment SET description = ? WHERE appointmentId = ?";
                PreparedStatement ps = conn.prepareStatement(sqlUpdateDescription);
                ps.setString(1, description);
                ps.setInt(2, appIdOld);
                ps.execute();
                calendarTable.getItems().clear();
                ObservableList<Appointment> appList = dba.getAllAppointments();
                calendarTable.setItems(appList);

            } else if (!typeOld.equalsIgnoreCase(type)) {

                String sqlUpdateType = "Update appointment SET type = ? WHERE appointmentId = ?";
                PreparedStatement ps = conn.prepareStatement(sqlUpdateType);
                ps.setString(1, type);
                ps.setInt(2, appIdOld);
                ps.execute();
                calendarTable.getItems().clear();
                ObservableList<Appointment> appList = dba.getAllAppointments();
                calendarTable.setItems(appList);

            } else if (!startOld.equals(ldtStart)) {

                while (rsSqlAppointmentTimes.next()) {

                    Timestamp startTime = rsSqlAppointmentTimes.getTimestamp("start");

                    ZoneId newzid = ZoneId.systemDefault();
                    ZonedDateTime newzdtStart = startTime.toLocalDateTime().atZone(ZoneId.of("UTC"));
                    ZonedDateTime newLocalStart = newzdtStart.withZoneSameInstant(newzid);

                    Timestamp endTime = rsSqlAppointmentTimes.getTimestamp("end");

                    ZonedDateTime newzdtEnd = endTime.toLocalDateTime().atZone(ZoneId.of("UTC"));
                    ZonedDateTime newLocalEnd = newzdtEnd.withZoneSameInstant(newzid);

                    if (sqlStart.equals(startTime) || sqlStart.after(startTime) && sqlStart.before(endTime)) {
                        alertStart = newLocalStart.toString();
                        alertEnd = newLocalEnd.toString();
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Time Conflict!");
                        alert.setContentText(alertStart + " and " + alertEnd + "There is already an appointment scheduled between the above times");
                        alert.setGraphic(null);
                        alert.showAndWait();
                        match++;

                    }
                }
                if (match < 2) {

                    String sqlUpdateStart = "Update appointment SET start = ? WHERE appointmentId = ?";
                    PreparedStatement ps = conn.prepareStatement(sqlUpdateStart);
                    ps.setTimestamp(1, sqlStart);
                    ps.setInt(2, appIdOld);
                    ps.execute();
                    calendarTable.getItems().clear();
                    ObservableList<Appointment> appList = dba.getAllAppointments();
                    calendarTable.setItems(appList);

                } else if (!endOld.equals(ldtEnd)) {

                    String sqlUpdateEnd = "Update appointment SET end = ? WHERE appointmentId = ?";
                    PreparedStatement ps = conn.prepareStatement(sqlUpdateEnd);
                    ps.setTimestamp(1, sqlEnd);
                    ps.setInt(2, appIdOld);
                    ps.execute();
                    calendarTable.getItems().clear();
                    ObservableList<Appointment> appList = dba.getAllAppointments();
                    calendarTable.setItems(appList);

                } else if (sHour.equals("01") || sHour.equals("02") || sHour.equals("03") || sHour.equals("04") || sHour.equals("05") || sHour.equals("06") || sHour.equals("07") || sHour.equals("08")
                        || sHour.equals("17") || sHour.equals("18") || sHour.equals("19") || sHour.equals("20") || sHour.equals("21") || sHour.equals("22") || sHour.equals("23") || sHour.equals("24")
                        || eHour.equals("01") || eHour.equals("02") || eHour.equals("03") || eHour.equals("04") || eHour.equals("05") || eHour.equals("06") || eHour.equals("07") || eHour.equals("08")
                        || eHour.equals("17") || eHour.equals("18") || eHour.equals("19") || eHour.equals("20") || eHour.equals("21") || eHour.equals("22") || eHour.equals("23") || eHour.equals("24")
                        || startDay.toString().equals("SATURDAY") || startDay.toString().equals("SUNDAY")) {
                    Alert alert2 = new Alert(Alert.AlertType.ERROR);
                    alert2.setTitle("Error");
                    alert2.setHeaderText("Invalid Appointment Time");
                    alert2.setContentText("Please set the appointment during our office hours. We are open Monday-Friday 9:00-17:00");
                    alert2.setGraphic(null);
                    alert2.showAndWait();

                } else if (ldtStart.isBefore(LocalDateTime.now())) {
                    Alert alert3 = new Alert(Alert.AlertType.ERROR);
                    alert3.setTitle("Error");
                    alert3.setContentText("You may not schedule an appointment in the past");
                    alert3.setGraphic(null);
                    alert3.showAndWait();

                } else if (ldtStart.isAfter(ldtEnd) || ldtStart.equals(ldtEnd)) {
                    Alert alert3 = new Alert(Alert.AlertType.ERROR);
                    alert3.setTitle("Error");
                    alert3.setContentText("Start time must be at least 15 minutes before End time");
                    alert3.setGraphic(null);
                    alert3.showAndWait();
                }

            } else {
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Saved!");
                alert.setContentText("Your appointment has been saved");
                alert.setGraphic(null);
                alert.showAndWait();

                calendarTable.getItems().clear();
                ObservableList<Appointment> appList = dba.getAllAppointments();
                calendarTable.setItems(appList);
            }
        }

    }

}
